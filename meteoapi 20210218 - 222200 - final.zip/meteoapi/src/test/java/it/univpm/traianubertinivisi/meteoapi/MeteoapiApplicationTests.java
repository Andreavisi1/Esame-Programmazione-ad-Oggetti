package it.univpm.traianubertinivisi.meteoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeteoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
