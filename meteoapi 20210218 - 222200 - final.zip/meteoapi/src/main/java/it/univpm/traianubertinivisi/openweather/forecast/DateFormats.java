package it.univpm.traianubertinivisi.openweather.forecast;

public final class DateFormats {
	public static String MySqlFormat = "yyyy-MM-dd HH:mm:ss";
}
