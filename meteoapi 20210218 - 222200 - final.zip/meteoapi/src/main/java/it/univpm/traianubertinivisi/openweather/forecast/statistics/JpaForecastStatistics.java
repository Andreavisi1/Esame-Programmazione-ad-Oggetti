package it.univpm.traianubertinivisi.openweather.forecast.statistics;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;

@Repository
public class JpaForecastStatistics implements ForecastStatisticsRepository {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public <S extends ForecastStatistics> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ForecastStatistics> Iterable<S> saveAll(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ForecastStatistics> findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Integer id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<ForecastStatistics> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<ForecastStatistics> findAllById(Iterable<Integer> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(ForecastStatistics entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends ForecastStatistics> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ForecastStatistics> findByName(String[] criteria) {
		// String[] criteria = {cityOrNull, country, start_date, end_date};
		String cityOrNull = criteria[0];
		String countryIdOrNull = criteria[1];
		String start_date = criteria[2];
		String end_date = criteria[3];
		
		cityOrNull = "" + cityOrNull.replace("!", "_").replace("*", "%");
		
		if (null == countryIdOrNull) countryIdOrNull = "*";
		
		countryIdOrNull= "" + countryIdOrNull.replace("!", "_").replace("*", "%");
		
		
		String cityWhere = "";
		
		String countryWhere = "";
		
		String[] cs = cityOrNull.split(",");
		for(int i = 0; i < cs.length; i++){
			cityWhere +=  ((cityWhere.length() > 0) ? " OR " : "") + " c.name like :name" + i;
		}
		
		String[] cis = countryIdOrNull.split(",");
		
		for(int i = 0; i < cis.length; i++){
			countryWhere +=  ((countryWhere.length() > 0) ? " OR " : "") + " c.country like :country" + i;
			
		}
			
		if (cityWhere.length() > 0) cityWhere = " and (" + cityWhere + " ) ";
		
		if (countryWhere.length() > 0) countryWhere = " and ( " + countryWhere + " ) ";
		
		String whereCondition = countryWhere + cityWhere; 
		

		
		StringBuilder sql = new StringBuilder("");
//		sql.append(" SET @cnt = 0; ");
		String nl = "\n";
		sql.append(" select id, count(city_id) as row_n, country, city_id, name, " + nl);
		sql.append(" '"+ start_date +"' as start, '" + end_date + "' as end, " + nl);
		sql.append(" min(visibility) as min_visibility, max(visibility) as max_visibility, avg(visibility) as avg_visibility, (max(visibility) - min(visibility)) as var_visibility, " + nl);
		sql.append(" min(pressure) as min_pressure, max(pressure) as max_pressure, avg(pressure) as avg_pressure, (max(pressure) - min(pressure)) as var_pressure " + nl);
		sql.append(" FROM forecasts as c " + nl);
		sql.append(" where (c.forecast_date BETWEEN '"+ start_date +"' AND '" + end_date + "')  " + nl);
		sql.append( whereCondition  + nl);
		sql.append(" group by c.city_id " + nl);
		sql.append(" order by c.name asc, c.city_id asc, c.forecast_date desc " + nl);
		
		System.out.println(sql.toString());
		
		Query query = em.createNativeQuery(sql.toString());
//		TypedQuery<ForecastStatistics> query = em.createQuery(sql.toString(), ForecastStatistics.class);
		
		for(int i = 0; i < cis.length; i++){
			query.setParameter("country"+i, cis[i]);
		}
		
		for(int i = 0; i < cs.length; i++){
			query.setParameter("name"+i, cs[i]);
		}
		
//		@SuppressWarnings("unchecked")
//		List<Object[]> obj = query.getResultList();
		
		
		return null;
	}

}
